package com.example.nearbychat.model

data class Message(
    val text: String,
    val mine: Boolean
)